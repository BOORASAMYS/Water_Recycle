import logging
import sys
import threading
from datetime import datetime, timezone
from typing import Any
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import urlopen

import fastapi
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

try:
    from pymodbus.client import ModbusTcpClient as _ModbusTcpClient
    _PYMODBUS_AVAILABLE = True
except ImportError:
    _PYMODBUS_AVAILABLE = False

# ---------------------------------------------------------------------------
# Logging — configure FIRST so every PLC / ESP message is visible in terminal
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
    datefmt="%H:%M:%S",
    stream=sys.stdout,
    force=True,
)
logger = logging.getLogger("water-management")
plc_logger = logging.getLogger("water-management.plc")
plc_logger.setLevel(logging.INFO)

# ---------------------------------------------------------------------------
# PLC configuration
# ---------------------------------------------------------------------------
PLC_IP = "192.168.1.50"
PLC_PORT = 502
PLC_SLAVE_ID = 1
PLC_TIMEOUT = 3

# house_id -> Modbus coil address used for the TAP open/close command
# r1on/r1off => coil 0, r2on/r2off => coil 1, etc.
PLC_TAP_COIL_MAP = {1: 0, 2: 1, 3: 2, 4: 3}

_plc_client: Any = None
_plc_lock = threading.Lock()


def _new_client():
    if not _PYMODBUS_AVAILABLE:
        return None
    return _ModbusTcpClient(PLC_IP, port=PLC_PORT, timeout=PLC_TIMEOUT)


def get_plc_client():
    """Return a *connected* Modbus TCP client, reconnecting if needed."""
    global _plc_client
    if not _PYMODBUS_AVAILABLE:
        return None
    if _plc_client is None:
        _plc_client = _new_client()
    try:
        ok = _plc_client.connect()
    except Exception as exc:
        plc_logger.error("PLC connect() raised: %s", exc)
        ok = False
    if not ok:
        try:
            _plc_client.close()
        except Exception:
            pass
        _plc_client = _new_client()
        try:
            ok = _plc_client.connect()
        except Exception as exc:
            plc_logger.error("PLC reconnect raised: %s", exc)
            ok = False
    return _plc_client if ok else None


def send_plc_tap(house_id: int, opened: bool) -> dict[str, Any]:
    """
    Send tap open/close command to PLC.
    opened=True  -> r<id>on  (coil = True)
    opened=False -> r<id>off (coil = False)
    """
    coil_addr = PLC_TAP_COIL_MAP.get(house_id)
    cmd = f"r{house_id}{'on' if opened else 'off'}"

    if coil_addr is None:
        plc_logger.warning("[PLC-TAP] no coil mapping for house_id=%s", house_id)
        return {"plc_sent": False, "reason": f"No coil mapping for house_id={house_id}", "cmd": cmd}

    if not _PYMODBUS_AVAILABLE:
        plc_logger.warning("[PLC-TAP] pymodbus not installed — skipping cmd=%s", cmd)
        return {"plc_sent": False, "reason": "pymodbus not installed", "cmd": cmd}

    plc_logger.info("[PLC-TAP] >>> cmd=%s | coil=%s | value=%s | %s:%s | slave=%s",
                    cmd, coil_addr, opened, PLC_IP, PLC_PORT, PLC_SLAVE_ID)

    with _plc_lock:
        client = get_plc_client()
        if client is None:
            plc_logger.error("[PLC-TAP] !!! cannot connect to %s:%s — cmd=%s skipped",
                             PLC_IP, PLC_PORT, cmd)
            return {"plc_sent": False, "reason": "PLC not reachable",
                    "cmd": cmd, "coil": coil_addr, "plc_ip": PLC_IP}
        try:
            try:
                result = client.write_coil(coil_addr, opened, slave=PLC_SLAVE_ID)
            except TypeError:
                result = client.write_coil(coil_addr, opened, unit=PLC_SLAVE_ID)
        except Exception as exc:
            plc_logger.exception("[PLC-TAP] !!! write exception cmd=%s", cmd)
            return {"plc_sent": False, "reason": str(exc),
                    "cmd": cmd, "coil": coil_addr, "plc_ip": PLC_IP}

        if result is None or (hasattr(result, "isError") and result.isError()):
            plc_logger.error("[PLC-TAP] !!! write error cmd=%s | result=%s", cmd, result)
            return {"plc_sent": False, "reason": str(result),
                    "cmd": cmd, "coil": coil_addr, "plc_ip": PLC_IP}

        plc_logger.info("[PLC-TAP] <<< OK cmd=%s | coil=%s | value=%s | result=%s",
                        cmd, coil_addr, opened, result)
        return {"plc_sent": True, "cmd": cmd, "coil": coil_addr,
                "value": opened, "plc_ip": PLC_IP, "slave": PLC_SLAVE_ID}


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------
app = fastapi.FastAPI(
    title="Water Management ESP Bridge API",
    version="1.1.0",
    description="Receives house water data from the frontend and forwards it to ESP / PLC.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

ESP_NODES = {
    1: {"ip": "192.168.0.4", "path": "/set"},
    2: {"ip": "192.168.0.5", "path": "/set"},
    3: {"ip": "192.168.0.6", "path": "/set"},
    4: {"ip": "192.168.0.7", "path": "/set"},
}
PURIFICATION_ESP_NODE = {"ip": "", "path": "/set"}

latest_house_data: dict[int, dict[str, Any]] = {}
latest_purification_data: dict[str, Any] = {}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class HouseWaterData(BaseModel):
    house_id: int = Field(..., ge=1)
    house_name: str
    amount_of_water_consumed: float = Field(..., ge=0)
    wallet_amount_present: float = Field(..., ge=0)


class HouseSyncRequest(BaseModel):
    houses: list[HouseWaterData]


class PurificationSyncRequest(BaseModel):
    amount_of_water_purified: float = Field(..., ge=0)
    purification_status: str = Field(..., pattern="^(ON|OFF)$")


class TapToggleRequest(BaseModel):
    house_id: int = Field(..., ge=1)
    opened: bool


def build_esp_url(ip: str, path: str) -> str:
    base_url = ip if ip.startswith(("http://", "https://")) else f"http://{ip}"
    return f"{base_url.rstrip('/')}/{path.lstrip('/')}"


def build_esp_set_url(house: HouseWaterData, ip: str, path: str) -> str:
    query = urlencode({
        "house": house.house_id,
        "consumed": round(house.amount_of_water_consumed, 2),
        "price": round(house.wallet_amount_present, 2),
    })
    return f"{build_esp_url(ip, path)}?{query}"


def build_purification_esp_url(payload: PurificationSyncRequest, ip: str, path: str) -> str:
    query = urlencode({
        "purified": round(payload.amount_of_water_purified, 2),
        "status": payload.purification_status,
    })
    return f"{build_esp_url(ip, path)}?{query}"


def send_purification_to_esp(payload: PurificationSyncRequest) -> dict[str, Any]:
    ip = PURIFICATION_ESP_NODE["ip"].strip()
    if not ip:
        logger.info("Purification ESP skipped | reason=ESP IP is blank")
        return {"esp_ip": "", "forwarded": False, "reason": "ESP IP is blank"}
    url = build_purification_esp_url(payload, ip, PURIFICATION_ESP_NODE["path"])
    logger.info("Purification ESP send | url=%s", url)
    try:
        with urlopen(url, timeout=3) as response:
            esp_response = response.read().decode("utf-8", errors="replace")
            logger.info("Purification ESP response | status=%s | body=%s", response.status, esp_response)
            return {"esp_ip": ip, "esp_url": url, "forwarded": True,
                    "method": "GET", "status_code": response.status, "esp_response": esp_response}
    except URLError as error:
        logger.warning("Purification ESP error | url=%s | error=%s", url, error)
        return {"esp_ip": ip, "esp_url": url, "forwarded": False, "error": str(error)}


def send_to_esp(house: HouseWaterData) -> dict[str, Any]:
    esp_config = ESP_NODES.get(house.house_id, {"ip": "", "path": "/set"})
    ip = esp_config["ip"].strip()
    if not ip:
        return {"house_id": house.house_id, "esp_ip": "", "forwarded": False, "reason": "ESP IP is blank"}
    url = build_esp_set_url(house, ip, esp_config["path"])
    logger.info("ESP send | house=%s | url=%s", house.house_id, url)
    try:
        with urlopen(url, timeout=3) as response:
            esp_response = response.read().decode("utf-8", errors="replace")
            logger.info("ESP response | house=%s | status=%s | body=%s",
                        house.house_id, response.status, esp_response)
            return {"house_id": house.house_id, "esp_ip": ip, "esp_url": url,
                    "forwarded": True, "method": "GET",
                    "status_code": response.status, "esp_response": esp_response}
    except URLError as error:
        logger.warning("ESP error | house=%s | url=%s | error=%s", house.house_id, url, error)
        return {"house_id": house.house_id, "esp_ip": ip, "esp_url": url,
                "forwarded": False, "error": str(error)}


# ---------------------------------------------------------------------------
# NEW: Tap toggle endpoint — called whenever the Open/Close Tap button is hit
# ---------------------------------------------------------------------------
@app.post("/api/houses/tap")
def toggle_tap(payload: TapToggleRequest) -> dict[str, Any]:
    if payload.house_id not in PLC_TAP_COIL_MAP:
        raise fastapi.HTTPException(status_code=422, detail="Invalid house_id")

    logger.info("=== TAP %s | house=%s ===",
                "OPEN" if payload.opened else "CLOSE", payload.house_id)
    plc_result = send_plc_tap(payload.house_id, payload.opened)
    logger.info("=== TAP result | house=%s | %s ===", payload.house_id, plc_result)

    return {
        "status": "ok",
        "house_id": payload.house_id,
        "opened": payload.opened,
        "received_at": utc_now(),
        "plc": plc_result,
    }


@app.get("/api/plc/test/{house_id}/{state}")
def plc_test(house_id: int, state: str) -> dict[str, Any]:
    """Manual PLC test, e.g. /api/plc/test/1/on or /api/plc/test/1/off"""
    return {"plc": send_plc_tap(house_id, state.lower() == "on")}


@app.get("/api/health")
def health_check() -> dict[str, str]:
    return {"status": "ok", "service": "water-management-esp-bridge",
            "pymodbus": str(_PYMODBUS_AVAILABLE)}


# Recharge endpoint kept for compatibility — no longer touches the PLC
@app.post("/api/houses/recharge")
def recharge_house(payload: dict = fastapi.Body(...)) -> dict[str, Any]:
    house_id = payload.get("house_id")
    amount = payload.get("amount", 0)
    logger.info("Recharge (wallet only) | house=%s | amount=%s", house_id, amount)
    return {"status": "ok", "house_id": house_id, "amount": amount, "received_at": utc_now()}


@app.post("/api/houses/sync")
def sync_house_data(payload: HouseSyncRequest) -> dict[str, Any]:
    received_at = utc_now()
    forwarding_results = []
    logger.info("House sync received | count=%s", len(payload.houses))
    for house in payload.houses:
        latest_house_data[house.house_id] = {**house.model_dump(), "received_at": received_at}
        forwarding_results.append(send_to_esp(house))
    return {"status": "ok", "received_at": received_at,
            "houses_received": len(payload.houses), "esp_forwarding": forwarding_results}


@app.post("/api/purification/sync")
def sync_purification_data(payload: PurificationSyncRequest) -> dict[str, Any]:
    received_at = utc_now()
    latest_purification_data.clear()
    latest_purification_data.update({**payload.model_dump(), "received_at": received_at})
    logger.info("Purification data | purified=%.2f | status=%s",
                payload.amount_of_water_purified, payload.purification_status)
    return {"status": "ok", "received_at": received_at,
            "esp_forwarding": send_purification_to_esp(payload)}
